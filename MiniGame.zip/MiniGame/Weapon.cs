﻿namespace MiniGame
{
    public class Weapon
    {
        protected float power;

        public Weapon(float power)
        {
            this.power = power;
        }
    }
}
